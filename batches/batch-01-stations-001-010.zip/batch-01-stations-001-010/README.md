# batch-01-stations-001-010

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 001 | Is the dark store open? | Foundations | 8/8 |
| 002 | Restaurant menu filters | Foundations | 16/16 |
| 003 | Product search autocomplete | Foundations | 19/19 |
| 004 | Event registration form | Foundations | 20/20 |
| 005 | Designing REST resources for gym classes | Foundations | 14/14 |
| 006 | One error shape for a banking API | Foundations | 20/20 |
| 007 | Comment moderation and XSS-safe output | Foundations | 27/27 |
| 008 | Saved delivery addresses | Foundations | 19/19 |
| 009 | Wishlist without duplicates | Foundations | 14/14 |
| 010 | Threaded comment replies | Foundations | 14/14 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
