# batch-08-stations-071-080

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 071 | Job portal sign-up and passwords | Working Systems | 14/14 |
| 072 | Password reset by email | Working Systems | 17/17 |
| 073 | Login with JWT for a fitness app | Working Systems | 16/16 |
| 074 | Device sessions for a streaming app | Working Systems | 21/21 |
| 075 | Sign in with Google | Working Systems | 19/19 |
| 076 | Passkey sign-in with WebAuthn | Working Systems | 22/22 |
| 077 | Hospital staff roles | Working Systems | 16/16 |
| 078 | Customers see only their own accounts | Working Systems | 16/16 |
| 079 | Document sharing with relationship-based permissions | Working Systems | 18/18 |
| 080 | Task board edits without lost updates | Working Systems | 14/14 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
