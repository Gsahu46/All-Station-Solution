# batch-03-stations-021-030

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 021 | Parsing a bank statement CSV | Foundations | 11/11 |
| 022 | Masking card and Aadhaar numbers in responses | Foundations | 15/15 |
| 023 | Accepting a partner's snake_case JSON | Foundations | 10/10 |
| 024 | Public holidays from a partner API | Foundations | 10/10 |
| 025 | OTP request limiter | Foundations | 14/14 |
| 026 | Request ids for parcel tracking | Foundations | 14/14 |
| 027 | Food order status flow | Foundations | 11/11 |
| 028 | Library book loans in layers | Foundations | 13/13 |
| 029 | Travel insurance premium factors | Foundations | 12/12 |
| 030 | Per-city delivery settings | Foundations | 14/14 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
