# batch-09-stations-081-090

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 081 | Who changed this price? | Working Systems | 19/19 |
| 082 | Movie seat holds | Working Systems | 13/13 |
| 083 | On-call doctor roster | Working Systems | 13/13 |
| 084 | Daily wallet limits | Working Systems | 15/15 |
| 085 | Idempotent UPI-style payments | Working Systems | 31/31 |
| 086 | One API for many payment providers | Working Systems | 25/25 |
| 087 | Saving cards with network tokens | Working Systems | 17/17 |
| 088 | Order API v2 without breaking old apps | Working Systems | 7/7 |
| 089 | App config with HTTP caching | Working Systems | 8/8 |
| 090 | Partner shipping-rate API docs | Working Systems | 11/11 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
