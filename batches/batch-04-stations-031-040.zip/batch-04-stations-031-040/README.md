# batch-04-stations-031-040

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 031 | Appointment reminders in many languages | Foundations | 12/12 |
| 032 | Return and refund eligibility | Foundations | 38/38 |
| 033 | Bug triage from a customer ticket | Foundations | 15/15 |
| 034 | Restaurant chain daily sales report | Foundations | 18/18 |
| 035 | Quiz leaderboard ranking | Foundations | 19/19 |
| 036 | Medicine search with plain JDBC | Foundations | 15/15 |
| 037 | Bus ticket booking in one transaction | Foundations | 15/15 |
| 038 | Gym memberships with migrations and constraints | Foundations | 12/12 |
| 039 | Human-friendly order numbers | Foundations | 17/17 |
| 040 | Short links with click counts | Foundations | 16/16 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
