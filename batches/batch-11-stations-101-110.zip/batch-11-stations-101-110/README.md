# batch-11-stations-101-110

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 101 | Task queue with RabbitMQ | Working Systems | 12/12 |
| 102 | Ticket sale when the pool runs dry | Working Systems | 10/10 |
| 103 | Calling a legacy SOAP service | Working Systems | 7/7 |
| 104 | Enterprise integration with Apache Camel | Working Systems | 10/10 |
| 105 | Support ticket summaries with an LLM API | Working Systems | 13/13 |
| 106 | Expose an API to AI agents with MCP | Working Systems | 11/11 |
| 107 | Partial refund approvals | Working Systems | 11/11 |
| 108 | Referral rewards without abuse | Working Systems | 15/15 |
| 109 | Tenant isolation in a CRM | Working Systems | 11/11 |
| 110 | Account deletion and data export | Working Systems | 12/12 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
