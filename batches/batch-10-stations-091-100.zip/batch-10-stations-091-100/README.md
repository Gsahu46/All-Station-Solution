# batch-10-stations-091-100

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 091 | Bulk shipment creation | Working Systems | 9/9 |
| 092 | KYC document upload | Working Systems | 12/12 |
| 093 | Order export to CSV | Working Systems | 12/12 |
| 094 | Image previews without SSRF | Working Systems | 12/12 |
| 095 | Webhooks to merchants | Working Systems | 17/17 |
| 096 | Partner API keys and quotas | Working Systems | 13/13 |
| 097 | Behind a load balancer | Working Systems | 12/12 |
| 098 | Invoice PDFs without blocking | Working Systems | 8/8 |
| 099 | Live order status with Server-Sent Events | Working Systems | 10/10 |
| 100 | Expiring unpaid hotel holds | Working Systems | 13/13 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
