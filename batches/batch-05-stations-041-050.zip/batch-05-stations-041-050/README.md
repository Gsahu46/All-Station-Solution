# batch-05-stations-041-050

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 041 | Clinic appointments report with joins | Foundations | 11/11 |
| 042 | Flash sale without overselling | Foundations | 10/10 |
| 043 | Doctor directory with JPA | Foundations | 11/11 |
| 044 | Hotel room availability calendar | Foundations | 18/18 |
| 045 | Order DTOs with MapStruct | Foundations | 10/10 |
| 046 | Employee leave requests | Foundations | 18/18 |
| 047 | Invoices and their line items | Foundations | 10/10 |
| 048 | Product reviews and ratings | Foundations | 12/12 |
| 049 | Course enrolments with progress | Foundations | 13/13 |
| 050 | Hotel booking request validation | Foundations | 12/12 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
