# batch-06-stations-051-060

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 051 | Webinar scheduling across time zones | Foundations | 10/10 |
| 052 | Bank notifications by channel | Foundations | 10/10 |
| 053 | Sign-up emails on MySQL and PostgreSQL | Foundations | 22/22 |
| 054 | Archiving seller products | Foundations | 11/11 |
| 055 | Checkout as one transaction | Working Systems | 11/11 |
| 056 | Timing and auditing with Spring AOP | Working Systems | 12/12 |
| 057 | Audit trail that survives a rollback | Working Systems | 9/9 |
| 058 | Welcome emails with Spring application events | Working Systems | 14/14 |
| 059 | Loyalty points tested on real PostgreSQL | Working Systems | 11/11 |
| 060 | Inventory sync with MySQL upserts | Working Systems | 18/18 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
