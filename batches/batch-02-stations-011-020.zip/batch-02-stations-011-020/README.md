# batch-02-stations-011-020

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 011 | Smart parking slot allocation | Foundations | 15/15 |
| 012 | Fleet vehicles: abstract classes vs interfaces | Foundations | 8/8 |
| 013 | Recently viewed products with an LRU cache | Foundations | 13/13 |
| 014 | Fare estimates per vehicle type | Foundations | 12/12 |
| 015 | Splitting a group bill | Foundations | 15/15 |
| 016 | Loan EMI calculator and schedule | Foundations | 12/12 |
| 017 | GST on invoices | Foundations | 11/11 |
| 018 | Payment methods with sealed interfaces | Foundations | 11/11 |
| 019 | A Money type for a multi-currency wallet | Foundations | 13/13 |
| 020 | Bank statement pages | Foundations | 12/12 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
