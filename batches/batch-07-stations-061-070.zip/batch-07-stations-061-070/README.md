# batch-07-stations-061-070

Stations in this batch (all pass tools/check_station.py):

| Station | Title | Stage | Tests |
|---|---|---|---|
| 061 | Restaurant list without N+1 queries | Working Systems | 13/13 |
| 062 | Shipment search by phone number | Working Systems | 10/10 |
| 063 | Hotel search with optional filters | Working Systems | 14/14 |
| 064 | Dish search with PostgreSQL full-text | Working Systems | 13/13 |
| 065 | Seller catalog pages | Working Systems | 11/11 |
| 066 | Social feed with keyset pagination | Working Systems | 11/11 |
| 067 | Category tree and breadcrumbs | Working Systems | 10/10 |
| 068 | Flexible product attributes with jsonb | Working Systems | 13/13 |
| 069 | Scheduled price changes | Working Systems | 14/14 |
| 070 | Product catalog on MongoDB | Working Systems | 12/12 |

Each `exports/NNN-slug/` folder follows the export contract in INTEGRATION.md:
- `page.html`: the station page as body content (for hosts that add their own <html>/<head>)
- `page-standalone.html`: the same page as a complete HTML document (open from disk, or any website)
- `station.json`: the same content as data (header facts, levels -> tabs -> html, test counts)
- `starter.zip`: the learner's Maven project, without solutions
- `solutions.zip`: the challenge solutions (offer only after the learner has tried)

`exports/index.json` lists only this batch. To integrate: copy `exports/*` into the website's stations folder
and add each index.json entry to the site's station list (see INTEGRATION_MAP.md once it exists).
