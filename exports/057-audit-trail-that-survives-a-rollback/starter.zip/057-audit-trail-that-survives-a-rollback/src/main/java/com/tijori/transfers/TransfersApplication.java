package com.tijori.transfers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransfersApplication {

    public static void main(String[] args) {
        SpringApplication.run(TransfersApplication.class, args);
    }
}
